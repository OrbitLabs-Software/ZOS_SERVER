#!/usr/bin/env bash
# Baut die zOS-Server-Installations-ISO (Debian-Installer + zOS-Einrichtung).
# Läuft auf jedem Linux (auch Ubuntu in WSL) mit Internet:
#   sudo apt install xorriso curl
#   ./build-iso.sh --core ai-core-5_4.zip [--out zos-server.iso] [--base debian-netinst.iso]
set -euo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
CORE="" BASE="" OUT="$PWD/zos-server-1.0-amd64.iso"
die() { echo "FEHLER: $*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --core) CORE="$(readlink -f "${2:?--core braucht eine ZIP-Datei}")"; shift 2;;
    --base) BASE="$(readlink -f "${2:?--base braucht eine ISO-Datei}")"; shift 2;;
    --out)  OUT="$(readlink -m "${2:?--out braucht einen Dateinamen}")"; shift 2;;
    -h|--help) sed -n '2,6p' "$0"; exit 0;;
    *) die "Unbekannte Option: $1";;
  esac
done
for t in xorriso curl sha256sum sed; do command -v "$t" >/dev/null || die "$t fehlt (sudo apt install xorriso curl)"; done
[ -z "$CORE" ] || [ -f "$CORE" ] || die "AI-Core-ZIP nicht gefunden: $CORE"
[ -f "$KIT/install.sh" ] && [ -d "$KIT/files" ] && [ -d "$KIT/iso" ] || die "Kit unvollständig"

WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT

# 1. Debian-Netinst-ISO holen und prüfen
if [ -z "$BASE" ]; then
  URL=https://cdimage.debian.org/debian-cd/current/amd64/iso-cd
  echo "==> Debian-Netinst-ISO suchen"
  NAME="$(curl -fsSL "$URL/" | grep -oE 'debian-[0-9][0-9.]*-amd64-netinst\.iso' | head -1)"
  [ -n "$NAME" ] || die "Konnte die aktuelle Debian-ISO nicht finden"
  echo "==> Lade $NAME"
  curl -fL --progress-bar -o "$WORK/$NAME" "$URL/$NAME"
  curl -fsSL -o "$WORK/SHA256SUMS" "$URL/SHA256SUMS"
  ( cd "$WORK" && grep " $NAME\$" SHA256SUMS | sha256sum -c - ) || die "Prüfsumme der Debian-ISO stimmt nicht"
  BASE="$WORK/$NAME"
fi
[ -f "$BASE" ] || die "Basis-ISO nicht gefunden"

# 2. Kernel/Initrd des Installers finden (grafisch bevorzugt)
LIST="$(xorriso -indev "$BASE" -find /install.amd -type f 2>/dev/null || true)"
grep -q "/install.amd/vmlinuz" <<<"$LIST" || die "Das ist keine Debian-amd64-Installations-ISO (/install.amd fehlt)"
TK=/install.amd/vmlinuz; TI=/install.amd/initrd.gz; K=$TK; I=$TI
if grep -q "/install.amd/gtk/vmlinuz" <<<"$LIST" && grep -q "/install.amd/gtk/initrd.gz" <<<"$LIST"; then K=/install.amd/gtk/vmlinuz; I=/install.amd/gtk/initrd.gz; fi
echo "==> Installer: $K"

# 3. Dateien vorbereiten
STAGE="$WORK/stage/zos"; mkdir -p "$STAGE"
cp -a "$KIT/install.sh" "$KIT/files" "$KIT/iso" "$STAGE/"
cp "$KIT/iso/preseed.cfg" "$STAGE/preseed.cfg"
[ -z "$CORE" ] || cp "$CORE" "$STAGE/ai-core.zip"
for f in isolinux.cfg zos.cfg grub.cfg; do
  sed -e "s|@KERNEL@|$K|g" -e "s|@INITRD@|$I|g" -e "s|@TKERNEL@|$TK|g" -e "s|@TINITRD@|$TI|g" "$KIT/iso/$f.in" > "$WORK/$f"
done

# 4. Neue ISO schreiben (Boot-Daten der Original-ISO bleiben erhalten: BIOS und UEFI)
echo "==> ISO schreiben: $OUT"
rm -f "$OUT"
xorriso -indev "$BASE" -outdev "$OUT" -boot_image any replay \
  -map "$STAGE" /zos \
  -map "$WORK/grub.cfg" /boot/grub/grub.cfg \
  -map "$WORK/isolinux.cfg" /isolinux/isolinux.cfg \
  -map "$WORK/zos.cfg" /isolinux/zos.cfg \
  -commit >/dev/null 2>"$WORK/xorriso.log" || { cat "$WORK/xorriso.log" >&2; die "xorriso ist fehlgeschlagen"; }

# 5. Kontrolle
CHECK="$(xorriso -indev "$OUT" -find /zos -maxdepth 1 2>/dev/null || true)"
for need in /zos/install.sh /zos/preseed.cfg /zos/iso; do grep -q "$need" <<<"$CHECK" || die "In der ISO fehlt $need"; done
echo "==> Fertig: $OUT ($(du -h "$OUT" | cut -f1))"
sha256sum "$OUT"
echo "Auf USB-Stick schreiben: Rufus (Windows, 'DD-Image-Modus') oder balenaEtcher."
