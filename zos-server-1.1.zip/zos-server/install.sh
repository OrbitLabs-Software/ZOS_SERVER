#!/usr/bin/env bash
# zOS Server – Installer
# Macht aus einem frisch installierten Debian 12/13 oder Ubuntu Server 22.04/24.04
# ein zOS Server: AI Core, Fernsteuerung, Browser, Panel, Firewall.
#
#   sudo ./install.sh [--core ai-core-5_4.zip] [--hostname NAME] [--with-ollama]
set -euo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
ZOS_VERSION="1.0"
CORE_ZIP="" HOSTNAME_NEW="zos-server" WITH_OLLAMA=0

die() { echo "FEHLER: $*" >&2; exit 1; }
say() { echo; echo "==> $*"; }

while [ $# -gt 0 ]; do
  case "$1" in
    --core) CORE_ZIP="$(readlink -f "${2:?--core braucht eine ZIP-Datei}")"; shift 2;;
    --hostname) HOSTNAME_NEW="${2:?}"; shift 2;;
    --with-ollama) WITH_OLLAMA=1; shift;;
    -h|--help) sed -n '2,8p' "$0"; exit 0;;
    *) die "Unbekannte Option: $1";;
  esac
done

[ "$(id -u)" = 0 ] || die "Bitte mit sudo ausführen: sudo ./install.sh"
[ -d "$KIT/files" ] || die "Ordner files/ fehlt neben install.sh"
[ -z "$CORE_ZIP" ] || [ -f "$CORE_ZIP" ] || die "ZIP nicht gefunden: $CORE_ZIP"
[[ "$HOSTNAME_NEW" =~ ^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$ ]] || die "Ungültiger Hostname"
command -v apt-get >/dev/null || die "Nur Debian/Ubuntu (apt) wird unterstützt"
. /etc/os-release
case "${ID:-}" in debian|ubuntu) ;; *) die "Nicht getestet für ${ID:-?} – unterstützt: Debian, Ubuntu";; esac
export DEBIAN_FRONTEND=noninteractive

# ---------------------------------------------------------------- Pakete
say "Pakete installieren"
apt-get update -qq
apt-get install -y -qq sudo curl unzip ca-certificates gnupg openssl jq ufw openssh-server avahi-daemon \
  xorg openbox tint2 xterm x11-xserver-utils lightdm lightdm-gtk-greeter x11vnc novnc websockify fonts-dejavu-core >/dev/null

# Node.js >= 20 (für AI Core)
NODE_MAJOR=0; command -v node >/dev/null && NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  say "Node.js 22 installieren (NodeSource)"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null
  apt-get install -y -qq nodejs >/dev/null
fi

# Firefox: Debian = firefox-esr, Ubuntu = Mozilla-Paketquelle (Snap vermeiden)
say "Webbrowser installieren"
if [ "$ID" = debian ]; then
  apt-get install -y -qq firefox-esr >/dev/null; FF=firefox-esr
else
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://packages.mozilla.org/apt/repo-signing-key.gpg -o /etc/apt/keyrings/packages.mozilla.org.asc
  echo "deb [signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://packages.mozilla.org/apt mozilla main" > /etc/apt/sources.list.d/mozilla.list
  printf 'Package: *\nPin: origin packages.mozilla.org\nPin-Priority: 1000\n' > /etc/apt/preferences.d/mozilla
  apt-get update -qq && apt-get install -y -qq firefox >/dev/null; FF=firefox
fi
printf '#!/bin/sh\nexec %s "$@"\n' "$FF" > /usr/local/bin/zos-browser; chmod 755 /usr/local/bin/zos-browser

# ---------------------------------------------------------------- Benutzer und Ordner
say "Benutzer und Ordner anlegen"
id zos >/dev/null 2>&1 || useradd -m -s /bin/bash -G video,audio zos
passwd -l zos >/dev/null
install -d -o zos -g zos /opt/zos/cores /opt/zos/panel /var/lib/zos/data /srv/zos/inbox /srv/zos/downloads /srv/zos/uploads
install -d -m 0755 /etc/zos /usr/share/zos/start
getent group sudo >/dev/null && { chgrp sudo /srv/zos/inbox; chmod 2775 /srv/zos/inbox; }   # Admin darf per scp ZIPs ablegen
install -m 0755 "$KIT/files/zos" /usr/local/bin/zos
install -m 0644 "$KIT/files/panel/server.js" "$KIT/files/panel/index.html" /opt/zos/panel/
install -m 0644 "$KIT/files/start/index.html" /usr/share/zos/start/index.html
echo "zos ALL=(root) NOPASSWD: /usr/local/bin/zos" > /etc/sudoers.d/zos
chmod 440 /etc/sudoers.d/zos; visudo -cf /etc/sudoers.d/zos >/dev/null

# ---------------------------------------------------------------- Browser-Richtlinien
say "Browser einrichten (Startseite, Downloads)"
POLICY='{"policies":{
 "Homepage":{"URL":"file:///usr/share/zos/start/index.html","StartPage":"homepage"},
 "OverrideFirstRunPage":"","OverridePostUpdatePage":"","NoDefaultBookmarks":true,
 "DownloadDirectory":"/srv/zos/downloads","DefaultDownloadDirectory":"/srv/zos/downloads","PromptForDownloadLocation":false,
 "DisableTelemetry":true,"DisableFirefoxStudies":true,"DontCheckDefaultBrowser":true,"DisplayBookmarksToolbar":"always",
 "Bookmarks":[
  {"Title":"AI Core","URL":"http://localhost:3000","Placement":"toolbar"},
  {"Title":"zOS Panel","URL":"http://localhost:8080","Placement":"toolbar"},
  {"Title":"Start","URL":"file:///usr/share/zos/start/index.html","Placement":"toolbar"}]}}'
for d in /etc/firefox/policies /usr/lib/firefox/distribution /usr/lib/firefox-esr/distribution; do
  mkdir -p "$d"; echo "$POLICY" | jq . > "$d/policies.json"
done

# ---------------------------------------------------------------- Desktop (Openbox, Autologin, ohne Monitor lauffähig)
say "Desktop und Autologin einrichten"
install -d -o zos -g zos /home/zos/.config/openbox
cat > /home/zos/.config/openbox/autostart <<'EOF'
xset s off -dpms s noblank
xsetroot -solid "#0b1020"
tint2 &
zos-browser &
EOF
cat > /home/zos/.config/openbox/menu.xml <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu xmlns="http://openbox.org/3.4/menu">
<menu id="root-menu" label="zOS Server">
  <item label="Browser"><action name="Execute"><command>zos-browser</command></action></item>
  <item label="AI Core"><action name="Execute"><command>zos-browser http://localhost:3000</command></action></item>
  <item label="zOS Panel"><action name="Execute"><command>zos-browser http://localhost:8080</command></action></item>
  <item label="Terminal"><action name="Execute"><command>xterm</command></action></item>
  <separator/>
  <item label="Neustart"><action name="Execute"><command>sudo /usr/local/bin/zos power reboot</command></action></item>
</menu>
</openbox_menu>
EOF
chown -R zos:zos /home/zos/.config
mkdir -p /etc/lightdm/lightdm.conf.d /etc/X11/xorg.conf.d
cat > /etc/lightdm/lightdm.conf.d/50-zos.conf <<'EOF'
[Seat:*]
autologin-user=zos
autologin-user-timeout=0
autologin-session=openbox
user-session=openbox
EOF
# Ohne angeschlossenen Monitor trotzdem einen Bildschirm bereitstellen
cat > /etc/X11/xorg.conf.d/20-zos-headless.conf <<'EOF'
Section "Device"
  Identifier "zos-gpu"
  Driver "modesetting"
  Option "AllowEmptyInitialConfiguration" "true"
EndSection
EOF
systemctl set-default graphical.target >/dev/null 2>&1 || true

# ---------------------------------------------------------------- Dienste
say "Dienste einrichten"
cat > /etc/systemd/system/zos-aicore.service <<'EOF'
[Unit]
Description=zOS – AI Core (aktive Version)
After=network-online.target ollama.service
Wants=network-online.target
ConditionPathExists=/opt/zos/current/server/server.js
[Service]
User=zos
WorkingDirectory=/opt/zos/current
Environment=NODE_ENV=production
ExecStart=/usr/bin/node server/server.js
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/zos-panel.service <<'EOF'
[Unit]
Description=zOS Panel (Weboberfläche)
After=network-online.target
Wants=network-online.target
[Service]
User=zos
ExecStart=/usr/bin/node /opt/zos/panel/server.js
Restart=always
RestartSec=3
PrivateTmp=true
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/zos-x11vnc.service <<'EOF'
[Unit]
Description=zOS Bildschirm-Fernsteuerung (nur lokal, erreichbar über das Panel)
After=display-manager.service
[Service]
ExecStart=/usr/bin/x11vnc -display :0 -auth guess -localhost -nopw -forever -shared -noxdamage -repeat -rfbport 5900 -quiet
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/zos-novnc.service <<'EOF'
[Unit]
Description=zOS noVNC (nur lokal, erreichbar über das Panel)
After=zos-x11vnc.service
[Service]
User=zos
ExecStart=/usr/bin/websockify --web /usr/share/novnc 127.0.0.1:6080 127.0.0.1:5900
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/zos-inbox.path <<'EOF'
[Unit]
Description=zOS Eingang für neue AI-Core-Versionen
[Path]
PathExistsGlob=/srv/zos/inbox/*.zip
Unit=zos-inbox.service
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/zos-inbox.service <<'EOF'
[Unit]
Description=zOS AI-Core-Versionen aus dem Eingang installieren
StartLimitIntervalSec=0
[Service]
Type=oneshot
ExecStart=/usr/local/bin/zos inbox
EOF
systemctl daemon-reload

# ---------------------------------------------------------------- Zugangsdaten
say "Panel-Passwort erzeugen"
PANEL_PW="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | cut -c1-16)"
printf '%s' "$PANEL_PW" | node /opt/zos/panel/server.js --set-password
chown zos:zos /etc/zos/panel.json; chmod 600 /etc/zos/panel.json
umask 077; printf 'zOS Server – Panel-Passwort: %s\nÄndern mit: sudo zos passwd\n' "$PANEL_PW" > /root/zos-first-run.txt; umask 022
mkdir -p /etc/issue.d
printf '\n  zOS Server – Panel-Passwort: %s   (ändern: sudo zos passwd)\n\n' "$PANEL_PW" > /etc/issue.d/50-zos-first-run.issue

# ---------------------------------------------------------------- AI Core
if [ -n "$CORE_ZIP" ]; then
  say "AI Core installieren"
  /usr/local/bin/zos install "$CORE_ZIP"
  CORE_VER="$(basename "$(ls -1d /opt/zos/cores/[0-9]* | sort -V | tail -1)")"
  systemctl enable zos-aicore >/dev/null 2>&1
  /usr/local/bin/zos activate "$CORE_VER" || echo "Hinweis: AI Core startet noch nicht – siehe: zos logs"
fi
if [ "$WITH_OLLAMA" = 1 ]; then say "Ollama installieren"; curl -fsSL https://ollama.com/install.sh | sh; fi

# ---------------------------------------------------------------- Namen und Aussehen
say "zOS-Kennzeichnung"
hostnamectl set-hostname "$HOSTNAME_NEW" 2>/dev/null || echo "$HOSTNAME_NEW" > /etc/hostname
if grep -q '^127.0.1.1' /etc/hosts; then sed -i "s/^127.0.1.1.*/127.0.1.1 $HOSTNAME_NEW/" /etc/hosts; else echo "127.0.1.1 $HOSTNAME_NEW" >> /etc/hosts; fi
echo "zOS Server $ZOS_VERSION" > /etc/zos-release
BASE="${PRETTY_NAME:-$NAME}"; BASE="${BASE#zOS Server $ZOS_VERSION (}"; BASE="${BASE%)}"
sed -i '/^PRETTY_NAME=/d;/^ZOS_VERSION=/d' /etc/os-release
printf 'PRETTY_NAME="zOS Server %s (%s)"\nZOS_VERSION="%s"\n' "$ZOS_VERSION" "$BASE" "$ZOS_VERSION" >> /etc/os-release
printf 'zOS Server %s \\n \\l\n\n' "$ZOS_VERSION" > /etc/issue
cat > /etc/motd <<EOF

  zOS Server $ZOS_VERSION
  Panel:    http://$HOSTNAME_NEW.local:8080
  AI Core:  http://$HOSTNAME_NEW.local:3000
  Hilfe:    zos help

EOF
if [ -f /etc/default/grub ]; then
  if grep -q '^GRUB_DISTRIBUTOR=' /etc/default/grub; then sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="zOS Server"/' /etc/default/grub
  else echo 'GRUB_DISTRIBUTOR="zOS Server"' >> /etc/default/grub; fi
  update-grub >/dev/null 2>&1 || true
fi

# ---------------------------------------------------------------- Firewall (nur Heimnetz)
say "Firewall"
SUBNET="$(ip -4 route show scope link | awk '!/default/ {print $1; exit}')"
if [ -n "$SUBNET" ]; then
  ufw --force reset >/dev/null; ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
  for p in 22 3000 8080; do ufw allow from "$SUBNET" to any port "$p" proto tcp >/dev/null; done
  ufw allow from "$SUBNET" to any port 5353 proto udp >/dev/null
  ufw --force enable >/dev/null; echo "Firewall an – Zugriff nur aus $SUBNET (Ports 22, 3000, 8080)"
else
  echo "WARNUNG: Heimnetz nicht erkannt – Firewall NICHT aktiviert."
fi

# ---------------------------------------------------------------- Start
systemctl enable --now ssh avahi-daemon zos-panel zos-inbox.path >/dev/null 2>&1 || true
systemctl enable zos-aicore zos-x11vnc zos-novnc lightdm >/dev/null 2>&1 || true

echo
echo "=============================================================="
echo " zOS Server $ZOS_VERSION ist installiert."
echo
echo " Panel:     http://$HOSTNAME_NEW.local:8080   (oder per IP-Adresse)"
echo " Passwort:  $PANEL_PW        (auch in /root/zos-first-run.txt)"
echo
echo " Bitte jetzt neu starten:  sudo reboot"
echo " Danach den Bildschirm vom PC aus: Panel → Bildschirm → Fernsteuerung einschalten."
echo "=============================================================="
