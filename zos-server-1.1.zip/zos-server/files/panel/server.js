#!/usr/bin/env node
// zOS Panel – Weboberfläche zur Verwaltung (ohne Abhängigkeiten, Node >= 18)
'use strict';
const http = require('http'), net = require('net'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { execFile } = require('child_process');

const CONF = process.env.ZOS_PANEL_CONF || '/etc/zos/panel.json';
const PORT = +(process.env.ZOS_PANEL_PORT || 8080);
const HOST = process.env.ZOS_PANEL_HOST || '0.0.0.0';
const ZOS = (process.env.ZOS_CMD || 'sudo -n /usr/local/bin/zos').split(' ');
const UPLOADS = process.env.ZOS_UPLOADS || '/srv/zos/uploads';
const DOWNLOADS = process.env.ZOS_DOWNLOADS || '/srv/zos/downloads';
const WEB = process.env.ZOS_WEB || path.join(__dirname, 'index.html');
const NOVNC = { host: '127.0.0.1', port: 6080 };
const MAX_UPLOAD = 1024 ** 3;
const VER_RE = /^[0-9]+(\.[0-9]+){1,3}([-+][A-Za-z0-9.]+)?$/;

// ---- Passwort ---------------------------------------------------------------
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 32); }
function checkPw(pw) {
  try {
    const c = JSON.parse(fs.readFileSync(CONF, 'utf8'));
    return crypto.timingSafeEqual(hashPw(String(pw), Buffer.from(c.salt, 'hex')), Buffer.from(c.hash, 'hex'));
  } catch { return false; }
}

if (process.argv[2] === '--set-password') {
  let d = '';
  process.stdin.on('data', c => d += c).on('end', () => {
    const pw = d.replace(/\r?\n$/, '');
    if (pw.length < 10) { console.error('Mindestens 10 Zeichen'); process.exit(1); }
    const salt = crypto.randomBytes(16);
    fs.writeFileSync(CONF, JSON.stringify({ salt: salt.toString('hex'), hash: hashPw(pw, salt).toString('hex') }), { mode: 0o600 });
  });
} else {
  start();
}

function start() {
  // ---- Sitzungen ------------------------------------------------------------
  const sessions = new Map(), fails = new Map();
  const cookie = (req, n) => { const m = (req.headers.cookie || '').split(/;\s*/).find(c => c.startsWith(n + '=')); return m ? m.slice(n.length + 1) : ''; };
  const authed = req => { const t = cookie(req, 'zos'); const e = sessions.get(t); if (e && e > Date.now()) return true; sessions.delete(t); return false; };
  setInterval(() => { for (const [t, e] of sessions) if (e < Date.now()) sessions.delete(t); }, 60000).unref();

  // ---- Hilfen ---------------------------------------------------------------
  function send(res, code, obj, type) {
    const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  }
  function readJson(req) {
    return new Promise((ok, no) => {
      let d = '';
      req.on('data', c => { d += c; if (d.length > 65536) { req.destroy(); no(new Error('zu groß')); } });
      req.on('end', () => { try { ok(d ? JSON.parse(d) : {}); } catch { no(new Error('Ungültiges JSON')); } });
    });
  }
  function run(args) {
    return new Promise(ok => execFile(ZOS[0], [...ZOS.slice(1), ...args], { timeout: 15 * 60 * 1000, maxBuffer: 8 << 20 },
      (err, out, errout) => ok({ code: err ? (typeof err.code === 'number' ? err.code : 1) : 0, out: (out || '') + (errout || '') })));
  }
  const safeName = n => path.basename(String(n || '')).replace(/[^A-Za-z0-9._-]/g, '_').replace(/^\.+/, '');
  async function zosJson(res, args) {
    const r = await run(args);
    if (r.code) return send(res, 500, { error: r.out.trim() });
    try { send(res, 200, JSON.parse(r.out)); } catch { send(res, 500, { error: 'Unerwartete Antwort' }); }
  }
  async function zosText(res, args) { const r = await run(args); send(res, r.code ? 400 : 200, { ok: !r.code, output: r.out.trim() }); }

  // ---- Upload einer neuen AI-Core-Version -----------------------------------
  function upload(req, res, url) {
    const name = safeName(url.searchParams.get('name'));
    if (!/\.zip$/i.test(name)) return send(res, 400, { error: 'Nur .zip-Dateien' });
    if ((+req.headers['content-length'] || 0) > MAX_UPLOAD) return send(res, 413, { error: 'Datei zu groß (max. 1 GB)' });
    fs.mkdirSync(UPLOADS, { recursive: true });
    const dest = path.join(UPLOADS, name), part = dest + '.part';
    let size = 0, aborted = false;
    const ws = fs.createWriteStream(part);
    const abort = () => { aborted = true; ws.destroy(); fs.rm(part, () => {}); };
    req.on('data', c => { size += c.length; if (size > MAX_UPLOAD && !aborted) { abort(); send(res, 413, { error: 'Datei zu groß (max. 1 GB)' }); } });
    req.on('aborted', abort);
    req.pipe(ws);
    ws.on('finish', async () => {
      if (aborted) return;
      fs.renameSync(part, dest);
      const r = await run(['install', dest]);
      fs.rm(dest, () => {});
      send(res, r.code ? 400 : 200, { ok: !r.code, output: r.out.trim() });
    });
    ws.on('error', () => { if (!res.headersSent) send(res, 500, { error: 'Schreibfehler' }); });
  }

  // ---- noVNC (nur nach Anmeldung) -------------------------------------------
  function proxyHttp(req, res) {
    const p = http.request({ ...NOVNC, path: req.url.replace(/^\/novnc/, '') || '/', method: req.method, headers: { ...req.headers, host: `${NOVNC.host}:${NOVNC.port}` } },
      r => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
    p.on('error', () => send(res, 502, { error: 'Fernsteuerung ist aus (zos remote on)' }));
    req.pipe(p);
  }

  const urlOk = u => /^https?:\/\/[^\s'"]+$/.test(u || '');
  const verOk = v => VER_RE.test(v || '');

  // ---- Server ---------------------------------------------------------------
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x'), p = url.pathname;
    try {
      if (req.method === 'GET' && p === '/') {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY',
          'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'"
        });
        return res.end(fs.readFileSync(WEB));
      }
      if (p === '/api/login' && req.method === 'POST') {
        const ip = req.socket.remoteAddress, f = fails.get(ip) || { n: 0, t: Date.now() };
        if (Date.now() - f.t > 60000) { f.n = 0; f.t = Date.now(); }
        if (f.n >= 5) return send(res, 429, { error: 'Zu viele Versuche – eine Minute warten' });
        const b = await readJson(req);
        if (!checkPw(b.password)) { f.n++; fails.set(ip, f); return send(res, 401, { error: 'Falsches Passwort' }); }
        const t = crypto.randomBytes(32).toString('hex');
        sessions.set(t, Date.now() + 12 * 3600e3);
        res.setHeader('Set-Cookie', `zos=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200`);
        return send(res, 200, { ok: true });
      }
      if (p === '/api/me') return send(res, authed(req) ? 200 : 401, { ok: authed(req) });
      if (!authed(req)) return send(res, 401, { error: 'Nicht angemeldet' });
      if (req.method === 'POST' && req.headers['x-zos'] !== '1') return send(res, 403, { error: 'Anfrage abgelehnt' });

      if (p === '/novnc' || p.startsWith('/novnc/')) return proxyHttp(req, res);
      if (p === '/api/logout' && req.method === 'POST') {
        sessions.delete(cookie(req, 'zos'));
        res.setHeader('Set-Cookie', 'zos=; Max-Age=0; Path=/');
        return send(res, 200, { ok: true });
      }
      if (p === '/api/status') return zosJson(res, ['status', '--json']);
      if (p === '/api/cores') return zosJson(res, ['list', '--json']);
      if (p === '/api/logs') return zosText(res, ['logs', '100']);
      if (p === '/api/upload' && req.method === 'POST') return upload(req, res, url);
      if (p === '/api/downloads') {
        fs.mkdirSync(DOWNLOADS, { recursive: true });
        const list = fs.readdirSync(DOWNLOADS, { withFileTypes: true }).filter(d => d.isFile() && !d.name.startsWith('.'))
          .map(d => { const s = fs.statSync(path.join(DOWNLOADS, d.name)); return { name: d.name, size: s.size, time: s.mtimeMs }; })
          .sort((a, b) => b.time - a.time);
        return send(res, 200, list);
      }
      if (p === '/api/dl' && req.method === 'GET') {
        const n = safeName(url.searchParams.get('name')), f = path.join(DOWNLOADS, n);
        if (!n || !fs.existsSync(f) || !fs.statSync(f).isFile()) return send(res, 404, { error: 'Nicht gefunden' });
        res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': fs.statSync(f).size, 'Content-Disposition': `attachment; filename="${n}"` });
        return fs.createReadStream(f).pipe(res);
      }
      if (req.method === 'POST') {
        const b = await readJson(req);
        switch (p) {
          case '/api/activate': return verOk(b.version) ? zosText(res, ['activate', b.version]) : send(res, 400, { error: 'Ungültige Version' });
          case '/api/remove': return verOk(b.version) ? zosText(res, ['remove', b.version]) : send(res, 400, { error: 'Ungültige Version' });
          case '/api/rollback': return zosText(res, ['rollback']);
          case '/api/service': return ['start', 'stop', 'restart'].includes(b.action) ? zosText(res, ['service', b.action]) : send(res, 400, { error: 'Ungültig' });
          case '/api/remote': return ['on', 'off'].includes(b.state) ? zosText(res, ['remote', b.state]) : send(res, 400, { error: 'Ungültig' });
          case '/api/power': return ['reboot', 'poweroff'].includes(b.action) ? zosText(res, ['power', b.action]) : send(res, 400, { error: 'Ungültig' });
          case '/api/fetch': return urlOk(b.url) ? zosText(res, ['fetch', b.url]) : send(res, 400, { error: 'Ungültige Adresse' });
          case '/api/install-url': return urlOk(b.url) ? zosText(res, ['install', b.url]) : send(res, 400, { error: 'Ungültige Adresse' });
          case '/api/dl-delete': {
            const n = safeName(b.name), f = path.join(DOWNLOADS, n);
            if (!n || !fs.existsSync(f)) return send(res, 404, { error: 'Nicht gefunden' });
            fs.unlinkSync(f);
            return send(res, 200, { ok: true });
          }
        }
      }
      send(res, 404, { error: 'Nicht gefunden' });
    } catch (e) { if (!res.headersSent) send(res, 400, { error: e.message }); else res.destroy(); }
  });

  server.on('upgrade', (req, sock, head) => {
    const o = req.headers.origin;
    let sameOrigin = true;
    try { if (o) sameOrigin = new URL(o).host === req.headers.host; } catch { sameOrigin = false; }
    if (!authed(req) || !sameOrigin || !req.url.startsWith('/novnc/websockify')) return sock.destroy();
    const up = net.connect(NOVNC.port, NOVNC.host, () => {
      const lines = [`${req.method} ${req.url.replace(/^\/novnc/, '')} HTTP/1.1`];
      for (let i = 0; i < req.rawHeaders.length; i += 2) lines.push(`${req.rawHeaders[i]}: ${req.rawHeaders[i + 1]}`);
      up.write(lines.join('\r\n') + '\r\n\r\n');
      if (head && head.length) up.write(head);
      sock.pipe(up).pipe(sock);
    });
    up.on('error', () => sock.destroy());
    sock.on('error', () => up.destroy());
    sock.on('close', () => up.destroy());
  });

  server.listen(PORT, HOST, () => console.log(`zOS Panel läuft auf http://${HOST}:${PORT}`));
  for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => process.exit(0));
}
