#!/usr/bin/env bash
# Läuft einmal beim ersten Start des frisch installierten Systems.
set -uo pipefail
KIT=/opt/zos-kit; LOG=/var/log/zos-install.log
HN="$(hostname)"; [[ "$HN" =~ ^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$ ]] || HN=zos-server
echo "zOS Server wird eingerichtet – das dauert einige Minuten. Protokoll: $LOG"
# Warten bis das Netzwerk wirklich da ist
for i in $(seq 1 60); do getent hosts deb.debian.org >/dev/null 2>&1 && break; sleep 2; done
ARGS=(--hostname "$HN"); [ -f "$KIT/ai-core.zip" ] && ARGS+=(--core "$KIT/ai-core.zip")
if "$KIT/install.sh" "${ARGS[@]}" >"$LOG" 2>&1; then
  systemctl disable zos-firstboot.service >/dev/null 2>&1
  echo "zOS Server ist eingerichtet. Neustart …"; sleep 5; systemctl reboot
else
  echo "FEHLER bei der zOS-Einrichtung – siehe $LOG. Wird beim nächsten Start erneut versucht." >&2
  exit 1
fi
