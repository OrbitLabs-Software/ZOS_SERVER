# zOS Server 1.0

zOS Server macht aus einem Tiny-PC mit frisch installiertem Debian oder Ubuntu Server einen eigenen Server mit:

- **AI Core** als Dauerdienst (deine `ai-core-5_4.zip` und alle späteren Versionen)
- **Bildschirmsteuerung vom PC aus**, direkt im Browser (noVNC, nichts zu installieren)
- **Versionsverwaltung**: neue AI-Core-Version rüberkopieren, aktivieren, bei Fehlstart automatisch zurück
- **Webbrowser** auf dem Server (Firefox) mit Startseite für localhost, Online-Aktivierung und Downloads
- **zOS Panel** (Weboberfläche) und das Kommando `zos`

Es ist ein Linux-System mit zOS-Schicht (Linux-Kern, apt, systemd). Einen eigenen Kern von Grund auf zu schreiben wäre kein Server-Betriebssystem, das du sinnvoll betreiben könntest.

## Fertige ISO mit Installationsassistent bauen

Statt Debian von Hand zu installieren, kannst du eine ISO bauen: vom USB-Stick starten, der Assistent fragt Festplatte, Benutzer und Passwort ab, richtet zOS Server samt AI Core ein und startet neu. Gebaut wird **nicht auf dem Tiny**, sondern einmalig:

**Weg A – ohne Linux, mit GitHub (empfohlen für Windows):**
1. Neues **privates** Repository auf GitHub anlegen und den Inhalt dieses Ordners hochladen (inklusive `core/ai-core.zip`).
2. Reiter *Actions* → *zOS Server ISO bauen* → *Run workflow*.
3. Nach wenigen Minuten die Datei `zos-server-iso` (enthält `zos-server.iso`) herunterladen.

**Weg B – auf einem Linux/WSL-Rechner mit Internet:**
```bash
sudo apt install xorriso curl
./build-iso.sh --core core/ai-core.zip --out zos-server.iso
```

**USB-Stick:** ISO mit Rufus (Windows, „DD-Image-Modus") oder balenaEtcher schreiben, Tiny davon starten (BIOS oder UEFI).

Ablauf: Installer (Deutsch, Zeitzone Wien) → Festplatte wählen, Benutzer anlegen → Neustart → beim ersten Start richtet sich zOS Server ein (einige Minuten, **Internet nötig**, Protokoll `/var/log/zos-install.log`) → automatischer Neustart. Das Panel-Passwort erscheint auf der Text-Konsole (Strg+Alt+F1) und steht in `/root/zos-first-run.txt`; ändern mit `sudo zos passwd`.

Die ISO basiert auf der offiziellen Debian-Netinst-ISO (Prüfsumme wird beim Bauen kontrolliert). Der Installer lädt die Pakete aus dem Internet.

## Ohne ISO einrichten (auf vorhandenem Debian/Ubuntu)

1. Auf den Tiny **Debian 13/12 (netinst)** oder **Ubuntu Server 24.04** installieren, „SSH-Server" ankreuzen.
2. Diesen Ordner und die AI-Core-ZIP auf den Tiny kopieren, z. B. vom Windows-PC:
   `scp -r zos-server ai-core-5_4.zip BENUTZER@IP-DES-TINY:~`
3. Auf dem Tiny:
   ```bash
   cd ~/zos-server
   sudo ./install.sh --core ~/ai-core-5_4.zip
   sudo reboot
   ```
   Optional: `--hostname NAME` (Standard `zos-server`), `--with-ollama`.
4. Am PC im Browser: `http://zos-server.local:8080` (oder die IP). Das Passwort steht am Ende der Installation und in `/root/zos-first-run.txt`. Ändern: `sudo zos passwd`.

## Benutzen

| Aufgabe | Panel | Kommando |
|---|---|---|
| Bildschirm des Servers steuern | Bildschirm → „Bildschirm öffnen" | – |
| Neue AI-Core-Version rüberkopieren | AI-Core-Versionen → ZIP hochladen | `scp ai-core-5_5.zip BENUTZER@IP:/srv/zos/inbox/` (wird automatisch installiert) oder `sudo zos install datei.zip` |
| Aus dem Internet installieren | AI-Core-Versionen → Adresse eintragen | `sudo zos install https://…/ai-core-5_5.zip` |
| Version aktivieren | Aktivieren | `sudo zos activate 5.5.0` |
| Zurück zur alten Version | „Zur vorherigen Version zurück" | `sudo zos rollback` |
| Datei aus dem Internet laden | Downloads | `sudo zos fetch https://…` |
| Einstellung ändern (.env) | – | `sudo zos set CLOUD_LABEL=DeepSeek` |

Chats, Daten und `.env` liegen **außerhalb** der Versionen (`/var/lib/zos/data`, `/etc/zos/ai-core.env`) und gelten für jede Version. Startet eine neu aktivierte Version nicht, wechselt zOS automatisch zurück.

Auf dem Tiny-Bildschirm öffnet sich nach dem Start Firefox mit der zOS-Startseite (Rechtsklick auf den Desktop = Menü). Downloads landen in `/srv/zos/downloads`.

## Sicherheit

- Die Firewall lässt nur dein Heimnetz auf die Ports 22, 3000 (AI Core) und 8080 (Panel).
- Die Fernsteuerung hört nur auf dem Server selbst und ist nur über das Panel erreichbar (Passwort, Anmeldesperre nach 5 Fehlversuchen).
- Das Panel läuft ohne HTTPS. Von außerhalb des Heimnetzes nur über Tailscale oder ein VPN.
- Eine neue Version wird vor der Installation geprüft (gültige ZIP, keine unsicheren Pfade oder Links, Paketname `ai-core`). Installiere trotzdem nur ZIPs aus Quellen, denen du vertraust: `npm install` führt Code aus dem Paket aus.

## Wichtig zu wissen

- **Ohne Monitor** startet der Bildschirm nicht immer zuverlässig. Ein HDMI-Dummy-Stecker (ein paar Euro) ist die sicherste Lösung.
- `install.sh` braucht Internet (Pakete, Node.js 22, Firefox, später `npm`).
- **Die ISO selbst konnte ich hier nicht bauen und nicht starten** (keine ISO-Werkzeuge, kein Internet). Ich habe nur den Ablauf von `build-iso.sh` mit einer Attrappe geprüft. Der erste Lauf ist deshalb ein Test: Probiere ihn in einer virtuellen Maschine (VirtualBox/QEMU) aus, bevor du den Tiny überschreibst.
- Getestet habe ich `zos` und das Panel gegen deine echte `ai-core-5_4.zip` (Installieren, Aktivieren, Rückwechsel, Löschen, Upload, Login, Sperren, abgelehnte Fremd-ZIPs). **`install.sh` selbst konnte ich hier nicht ausführen** (kein apt, kein Root, kein Netz), nur die Syntax prüfen. Bei einem Fehler: Meldung kopieren, dann passe ich es an.
